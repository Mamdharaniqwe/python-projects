export const PORT = 5555;

export const mongoDBURL ="mongodb+srv://root:arjuncvinod@book-store.qoibc7b.mongodb.net/book-collection?retryWrites=true&w=majority";

// Please create a free database for yourself.
// This database will be deleted after tutorial